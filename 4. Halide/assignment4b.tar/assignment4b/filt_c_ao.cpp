#include <stdio.h>
#include <stdlib.h>
#include "filt_ao.h"
#include "HalideBuffer.h"
#include "halide_image_io.h"



//using namespace Halide;
using namespace Halide::Tools;



double Blur[] =
{
    0.0, 0.0,  0.05,  0.0,  0.0,
    0.0, 0.05, 0.1,  0.05,  0.0,
    0.05, 0.1,  0.2,   0.1,  0.05,
    0.0, 0.05, 0.1,  0.05,  0.0,
    0.0, 0.0,  0.05,  0.0,  0.0
};

double Edge[] =
{
    0,  -1,  0,
    -1,  4, -1,
    0,  -1, 0
};







int main ( int argc, char**argv )
{


int radius=40;
int n;
float * Kernel;
float sum;
int k;


Halide::Runtime::Buffer <uint8_t> input = load_image("in.png");


Halide::Runtime::Buffer <uint8_t> out(input.width(),input.height(),input.channels());
Halide::Runtime::Buffer <double> bl(Blur,5,5);
Halide::Runtime::Buffer <double> ed(Edge,3,3);




FrameBuffer(input,ed,bl,out);




save_image(out,"out.png");

    return 0;
}
