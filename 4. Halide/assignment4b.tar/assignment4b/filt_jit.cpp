#include "Halide.h"
#include "stdio.h"
#include "halide_image_io.h"



using namespace Halide;
using namespace Halide::Tools;
using namespace std;

#define filterWidth 3
#define filterHeight 3
int main(int argc, char **argv)
{


  double Blurt[] =
  {
      0.0, 0.0,  0.05,  0.0,  0.0,
      0.0, 0.05, 0.1,  0.05,  0.0,
      0.05, 0.1,  0.2,   0.1,  0.05,
      0.0, 0.05, 0.1,  0.05,  0.0,
      0.0, 0.0,  0.05,  0.0,  0.0
  };

  double Edget[] =
  {
      0,  -1,  0,
      -1,  4, -1,
      0,  -1, 0
  };








  int radius=40;
  int n;
  int blurfW = 5;
  int blurfH = 5;









Var x,y,c;
Func edgeBuffer("edgeBuffer"),FrameBuffer("FrameBuffer");
Func I("I"),Mask("Mask"),Mask2("Mask2"),output,Maskf("Maskf");
Func Kernel("Kernel"),Kernelt("Kernelt");




//Load our input image using a helper function
Buffer <uint8_t> input= load_image("in.png");

//Create the buffer for our output image
Buffer <uint8_t> out(input.width(),input.height(),input.channels());

//Wrap the C arrays into something that Halide understands
Buffer <double> Blur(Blurt,5,5);
Buffer <double> Edge(Edget,3,3);


///////////////////////////////////////////////////////////////////
//local color correction


//Create the kernel
RDom KD(0,2*radius+1);
Kernelt(x)=undef<float>();
Kernelt(KD)=cast<float>(exp(cast<double>(-2.0f *(-radius+KD)*(-radius+KD)/(radius*radius))));
Expr sumt=sum(Kernelt(KD));
Kernel(x)=Kernelt(x);
Kernel(KD)=cast<float>(Kernelt(KD)/sumt);



Func clamped;// the statement below takes care of boundary conditions for us (similar to the if statement in the C implementation)
clamped=BoundaryConditions::repeat_edge(input);



I(x,y)=((clamped(x,y,0)/255.0f) + (clamped(x,y,1)/255.0f) + (clamped(x,y,2)/255.0f))/ 3.0f;
Mask(x,y)= I (x,y);

RDom t(-radius,2*radius+1); // Creates a reduction domain that runs from -radius until radius

/*Convolve in the x direction*/
Mask2(x,y)=cast<float>(0);
Mask2(x,y)=Mask2(x,y)+(Mask(x+t,y)*Kernel(t+radius));

/*Convolve in the y direction*/
Maskf(x,y)=cast<float>(0);
Maskf(x,y)=Maskf(x,y)+(Mask2(x,y+t)*Kernel(t+radius));

Maskf(x,y)=2*Maskf(x,y)-1;
Maskf(x,y)=pow(2.0f,Maskf(x,y));
output(x,y,c)=cast<uint8_t>(min(255,255*pow((input(x,y,c)/255.0f),Maskf(x,y))));



///////////////////////////////////////////////////////////////////
//Main filter
Expr w =input.width();
Expr h = input.height();
Expr imageWidth  = w;
Expr imageHeight = h;
RDom f(0,filterWidth,0,filterHeight);

Expr imageX = (x-filterWidth / 2 + f.x + imageWidth ) % imageWidth;
Expr imageY = y - filterHeight / 2 + f.y;

imageY = max (imageY , 0);
imageY = min(imageY, (input.height()-1));
Expr red = cast<double>(0);
Expr green = cast<double>(0);
Expr blue  = cast<double>(0);
red =red+(output(imageX,imageY,0)*Edge(f.x,f.y));
green=green+( output(imageX,imageY,1)*Edge(f.x,f.y));
blue=blue+(output(imageX,imageY,2)*Edge(f.x,f.y));

edgeBuffer(x,y)=undef<double>();
edgeBuffer(x,y)=((cast<double>(red+green+blue)/3)  /cast<double>(255));
edgeBuffer(x,y)=cast<double>((select(edgeBuffer(x,y)>.08f,1.0f,0.0f)));


int fw=20;

Expr valr=sqrt(pow(fw/cast<double>(imageWidth)*(x-(imageWidth) / 2),2)+pow(fw/cast<double>(imageHeight)*(y-imageHeight / 2),2));
Expr valg = sqrt ( pow ( fw/cast<double>(imageWidth)*( x - 50 - imageWidth / 2 ), 2 ) + pow ( (fw/cast<double>(imageHeight))*( y + 75 - imageHeight / 2 ), 2 ) );
Expr valb = sqrt ( pow ( fw/cast<double>(imageWidth)*( x + 50 - imageWidth / 2 ), 2 ) + pow ( (fw/cast<double>(imageHeight))*( y + 75 - imageHeight / 2 ), 2 ) );
Expr val  = sqrt ( pow (fw/cast<double>(imageWidth)*( x - imageWidth / 2 ), 2 )      + pow ( (fw/cast<double>(imageHeight))*( y - imageHeight / 2 ), 2 ) );

valr=valr/255;
valg=valg/255;
valb=valb/255;
val=val/255;

imageX=(x-blurfW/2 + f.x + imageWidth) % imageWidth;
imageY=(y-blurfH/2 + f.y);
imageY=max(imageY,0);
imageY=min(imageY,(imageHeight-1));


Expr redt=cast<double>(0);
redt=redt+(output(imageX,imageY,0)*Blur(f.x,f.y));
Expr greent=cast<double>(0);
greent=greent+(output(imageX,imageY,1)*Blur(f.x,f.y));
Expr bluet=cast<double>(0);
bluet=bluet+(output(imageX,imageY,2)*Blur(f.x,f.y));


Expr reds=cast<double>(output(x,y,0));
Expr greens=cast<double>(output(x,y,1));
Expr blues=cast<double>(output(x,y,2));

red=(reds*(1.0f-val)+val*redt);
green=(greens*(1.0f-val)+val*greent);
blue=(blues*(1.0f-val)+val*bluet);


red=select(edgeBuffer(x,y)==0,red,reds);
green=select(edgeBuffer(x,y)==0,green,greens);
blue=select(edgeBuffer(x,y)==0,blue,blues);
FrameBuffer(x,y,c)=cast<unsigned char>(0);

FrameBuffer(x,y,0)=cast<unsigned char>(min ( max ( cast <int> ( (1.3f + valr *0.3f)*red + 0),0),255));
FrameBuffer(x,y,1)=cast<unsigned char>(min ( max ( cast <int> ( (1.0f + valg *0.3f)*green + 0),0),255));
FrameBuffer(x,y,2)=cast<unsigned char>(min ( max ( cast <int> ( (0.7f + valr *0.3f)*blue + 0),0),255));


Expr factx= 10.0f/cast<double>(input.width());
Expr facty= 10.0f/cast<double>(input.height());

val=(7-sqrt((pow(x*factx-5,2))+(pow(y*facty-5,2))));
val=(val/7);

FrameBuffer(x,y,0)=cast<unsigned char>(min ( max ( cast <int>(val*FrameBuffer(x,y,0)),0),255));
FrameBuffer(x,y,1)=cast<unsigned char>(min ( max ( cast <int>(val*FrameBuffer(x,y,1)),0),255));
FrameBuffer(x,y,2)=cast<unsigned char>(min ( max ( cast <int>(val*FrameBuffer(x,y,2)),0),255));



//Schedules

//TODO: input your schedules here
//The Funcs we may want to optimize are : Mask,Mask2, Maskf, output, edgeBuffer, FrameBuffer


Kernelt.compute_root();//produce the Kernel as root to avoid recomputation
Kernel.compute_root();

//FrameBuffer.print_loop_nest();//this statement will print the loop nest of our output function
Target target = get_host_target();
target.set_feature(Target::Profile);

FrameBuffer.compile_jit(target);
FrameBuffer.realize(out,target);//realize our code over the domain specified by the output buffer
save_image(out,"out.png");


return 0;
}
